
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jatin07',
  applicationName: 'step-function',
  appUid: 'ccZJQzCx4Dp8c9fgjV',
  orgUid: '4333d04e-1c7f-4fec-9461-acb2f297e01d',
  deploymentUid: 'd79ac903-2fb0-43da-b523-b36929efc803',
  serviceName: 'step-function',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.6.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'second_lambda_function_dev', timeout: 900 };

try {
  const userHandler = require('./second_lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}